package edu.ranken.thomasperrier.androidhot1measurementconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Toast;
import android.os.Bundle;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    final double MININPUT = 5.0;
    final double MILESTOKILOMETERS = 1.6093;
    final double KILOMETERSTOMILES = 0.6214;
    final String MTOK = "Miles to Kilometers Conversion";
    final String KTOM = "Kilometers to Miles Conversion";
    final String OORINPUT = "Input Entered Was Out Of Range.\nInput Must Be At Least "+MININPUT;

    EditText editTextNumber;
    TextView subTitle;
    TextView textViewResults;
    Button buttonConvertMToK;
    Button buttonConvertKToM;
    DecimalFormat pattern1 = new DecimalFormat("##0.00");


    double input = 0.0;
    double miles = 0.0;
    double kilometers = 0.0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextNumber = (EditText) findViewById(R.id.editTextNumber);
        textViewResults = (TextView) findViewById(R.id.textViewResult);
        subTitle = (TextView) findViewById(R.id.subTitle);
        buttonConvertMToK = (Button) findViewById(R.id.buttonConvertMToK);
        buttonConvertKToM = (Button) findViewById(R.id.buttonConvertKToM);

        buttonConvertMToK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean keepGoing = true;

                if (keepGoing) {
                    keepGoing = validateInput();
                }

                if (keepGoing) {
                    kilometers = convertMilesToKilometers();
                    displayMToKResults();
                }
            }
        });

        buttonConvertKToM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean keepGoing = true;

                if (keepGoing) {
                    keepGoing = validateInput();
                }

                if (keepGoing) {
                    miles = convertKilometersToMiles();
                    displayKToMResults();
                }
            }
        });
    }

    private boolean validateInput(){
        try{
            //  Read value from editTextHeight
            input = Double.parseDouble(editTextNumber.getText().toString());


            while(input < MININPUT){
                input = 0;
                editTextNumber.setText("");
                editTextNumber.requestFocus();
                throw new NumberFormatException();
            }

            return true;
        }
        catch(NumberFormatException nfe){
            Toast toast = Toast.makeText(getApplicationContext(), OORINPUT, Toast.LENGTH_LONG);
            toast.show();

            return false;
        }
    }

    private double convertMilesToKilometers(){
        kilometers = input * MILESTOKILOMETERS;

        return kilometers;
    }

    private double convertKilometersToMiles(){
        miles = input * KILOMETERSTOMILES;

        return miles;
    }

    private void displayMToKResults(){
        subTitle.setText(MTOK);
        textViewResults.setText("There are " + pattern1.format(kilometers) + " Kilometers in " + pattern1.format(input)+" Miles");
    }

    private void displayKToMResults(){
        subTitle.setText(KTOM);
        textViewResults.setText("There are " + pattern1.format(miles) + " Miles in " + pattern1.format(input)+" Kilometers");
    }
}
