package edu.ranken.thomasperrier.androidhot1rectanglecalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Toast;
import android.os.Bundle;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    final double MINHEIGHT = 12;
    final double MINWIDTH = 12;
    final String OORHEIGHT = "Height Inputted Out Of Range.\nHeight Must Be At Least " + MINHEIGHT;
    final String OORWIDTH = "Width Inputted Out Of Range.\nWidth Must Be At Least " + MINWIDTH;

    EditText editTextHeight;
    EditText editTextWidth;
    TextView textViewArea;
    TextView textViewPerimeter;
    Button buttonCalculate;
    Button buttonClear;
    DecimalFormat pattern1 = new DecimalFormat("##0.00");

    double height = 0.0;
    double width = 0.0;
    double area = 0.0;
    double perimeter = 0.0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextHeight = (EditText) findViewById(R.id.editTextHeight);
        editTextWidth = (EditText) findViewById(R.id.editTextWidth);
        textViewArea = (TextView) findViewById(R.id.textViewArea);
        textViewPerimeter = (TextView) findViewById(R.id.textViewPerimeter);
        buttonCalculate = (Button) findViewById(R.id.buttonCalculate);
        buttonClear = (Button) findViewById(R.id.buttonClear);

        buttonCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean keepGoing = true;

                if (keepGoing) {
                    keepGoing = validateHeight();
                }

                if (keepGoing) {
                    keepGoing = validateWidth();
                }

                if (keepGoing){
                    area = calculateArea();
                    perimeter = calculatePerimeter();
                    displayResults();
                }
            }
        });

        buttonClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearAll();
            }
        });
    }

    private boolean validateHeight(){
        try{
            //  Read value from editTextHeight
            height = Double.parseDouble(editTextHeight.getText().toString());


            while(height < MINHEIGHT){
                height = 0;
                editTextHeight.setText("");
                editTextHeight.requestFocus();
                throw new NumberFormatException();
            }

            return true;
        }
        catch(NumberFormatException nfe){
            Toast toast = Toast.makeText(getApplicationContext(), OORHEIGHT, Toast.LENGTH_LONG);
            toast.show();

            return false;
        }
    }

    private boolean validateWidth(){
        try{
            width = Double.parseDouble(editTextWidth.getText().toString());

            while(width < MINWIDTH){
                width = 0;
                editTextWidth.setText("");
                editTextWidth.requestFocus();
                throw new NumberFormatException();
            }

            return true;
        }
        catch(NumberFormatException nfe){
            Toast toast = Toast.makeText(getApplicationContext(), OORWIDTH, Toast.LENGTH_LONG);
            toast.show();

            return false;
        }
    }

    private void clearAll(){
        editTextHeight.setText("");
        editTextWidth.setText("");
        textViewPerimeter.setText("");
        textViewArea.setText("");
        editTextHeight.requestFocus();
    }

    private double calculateArea(){

        area = width * height;

        return area;
    }

    private double calculatePerimeter(){
        perimeter = 2 * (width+height);

        return perimeter;
    }

    private void displayResults(){
        textViewArea.setText(pattern1.format(area));
        textViewPerimeter.setText(pattern1.format(perimeter));
    }
}
